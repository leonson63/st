/*		BTP syntax

'...' - insert text
^N|[-]n|^ - remove to clipboard from/until mark N | n characters | from /^

+n - n chars forward
-n - n chars backward

#N set mark N
@N go to mark N
! - insert from clipboard
*n set loop count to n
{ - begin loop, $=0
= exit loop, goto related }
} end of loop, goto related { if not eof and loop count>0
?'...'|_|.|0 ...:...;   if at text '...'(white space | not white space | digit)
       do befor ':' else after till ';'
? ...:...; check white space
~ = '\r\n'
> - goto the start of next line
< - goto the begin of line
$ - flush data
(comment) - comment


find lines contained "AAA":  	{%'\r\n'#M@B%M'AAA'?M^B;}
				{#A{?'AAA'{?'~'=:+1;}+2^A:{?~=:+1;}}:+1;}
shift text right at 5 space: 	{*5{' '}>}
trancate at 40 pos  		{*40{?'~'=:+;}?'~':#M%'~'^M}
numerize lines			{$'. '%~}
replace all "AAA" with "BBB"	{?'AAA'#M-3^M'BBB':+1}

*/
#include <stdio.h>
#include <io.h>
#include <string.h>
#include <mem.h>
#include <stdlib.h>
#include <DOS.h>

#define	BUFF	(20L*1024)      /* text & clipboard buffer size */
#define PROG    4096            /* programm buffer size */

char *Prog;
char *p;

char    *T;
long int TLen;
int      t;
int      Mark['Z'-'A'];
char    *Clip;
int      ClipLen=0;
struct
      {
      unsigned long count;
      unsigned long limit;
      }
      Loop[10];
int      LoopLevel=0;

unsigned DelFrom=BUFF; /* delete from position for /^ */
long int FindCount=0;  /* / count */
int      End=0;        /* end of input flag */

char     tmpstr[100];      /* template string */
char     format[100]="%";  /* number output format string */


void     skip(char c);
void	 movp(int);
unsigned get_number(void); /* read number from p */
int      wspace(void);  /* check whether or not at the white space */
int      tflush(unsigned,int); /* flash text */
int      test(void);           /* test "< M . _ 'abc' nnn" */
int      cmps(void);           /* compare text and pattern string */


int main(int argc,char **argv)
    {
    int i;
    int l;
    int c;
    int comment;
//    int reg;
    char *p1;
    char *p2;
    FILE *f;
    unsigned long ll;

//    if(feof(stdin)) printf("EOF"); return 0;

    if(argc<2)
	return printf("Batch Text Processor V2.09, (C) A.Polyakov,"
						"March'2004\n"),0;

    T=malloc(BUFF); t=0; Clip=malloc(BUFF);
    if(T==NULL || Clip==NULL || (Prog=malloc(PROG))==NULL)
	return printf("Can\'t allocale  memory\r\n"),1;
    p=Prog;
    if(argv[1][0]=='@')
      {
      if( (f=fopen(&argv[1][1],"r"))==NULL ||
          !(l=fread(T,1,PROG,f)) ||
          fclose(f) )
             return fprintf(stderr,"Can't read programm file %s",&argv[1][1]),5;
      T[l]=0; p1=T;
      }
    else
        p1=argv[1];
    l=0; c=0; comment=0;
    while(*p1) switch(*p1)
	 {
	 case '~' : if(!c) *p++='\'';   //add ' if no
                    *p++='\n',p1++;
                    if(!c) *p++='\'';   //add ' if no
                    break;
         case '\\': p2=p; p= ++p1; i=get_number(); p1=p; p=p2;
              if(c) /* in 'character string' only! */
                   {
                   if(i) *p++=i; else *p++=*p1++;
                   }
              else *p++='\\';
              break;
	 default:
           if(*p1=='\'' && !comment) c=!c;
           if(*p1=='(' && !c) comment++;
//           if((p1=='[' && !c && !comment) reg=1;

           if(!c && (*p1==' '||*p1=='\t'||*p1=='\n'||comment)) p1++;
                          /* skip white space  and comments*/
                  else *p++ = *p1++;
           if(p1[-1]==')' && !c) comment--;
//           if(p[-1]==']' && !c && !comment) reg=0;
	 }
    if(c) return fprintf(stderr,"Unbalansed text, missing '"),6;
    if(comment) return fprintf(stderr,"Unbalansed comments, missing ')'"),6;
    *p=0; p=Prog;
    for(i=0;i<'Z'-'A'; i++) Mark[i]=0;
//    TLen=read(fileno(stdin),T,BUFF*2/3);
    TLen=t=0; tflush(0,1);
    Mark['E'-'A']=TLen;

    Loop[0].limit=0; //unlimited loop

    while(*p) switch( _AH=0xb,geninterrupt(0x21),  *p++)
	{
	case '\'':for(l=0;*p!='\'';p++,l++)
			if(!*p) return fprintf(stderr,"missing '"),2;
                  if((long)TLen+l>=BUFF) tflush(l,0);
                  if((long)TLen+l>=BUFF) fprintf(stderr,"buffer overflow %s",p-l),exit(4);
		  movp(l); movmem(T+t,T+t+l,TLen-t);movmem(p-l,T+t,l); p++;
		  t+=l; TLen+=l; break;
	case '^': c=0; if(*p=='-') p++,c=1;
                  if(*p=='/')
                      {
                      p++;
                      if(DelFrom!=BUFF) i=DelFrom, DelFrom=BUFF;
                      else fprintf(stderr,"^/ without /^"),exit(2);
                      }
                  else
                      {
                      i=get_number();
                      if(i) i= (c?t-i:t+i);
                      else {if(*p>='A' && *p<='Z') i=Mark[*p++-'A'];
                           else fprintf(stderr,"unknown char after ^"),exit(2);
                           }
                      }
                  if(i>TLen) i=TLen; if(i<0) i=0;
		  if(i>t) {movmem(T+t,Clip,ClipLen=i-t);
			   movmem(T+i,T+t,TLen-i); TLen-=ClipLen;}
		  else	  {movmem(T+i,Clip,ClipLen=t-i);
			   movmem(T+t,T+i,TLen-t); TLen-=ClipLen;t=i;}
		  movp(-ClipLen);
		  break;
	case '+': i=get_number(); if(!i) i=1;
                  if(t+i>=TLen) tflush(0,1); t=(t+i<TLen)? t+i:TLen; break;
	case '-': i=get_number(); t-=i?i:1;
                  if(t<0) return fprintf(stderr, "out of bound: %n",p),3;
                  break;
	case '#': if(*p>='A' && *p<='Z') Mark[*p++-'A']=t;
                  else return fprintf(stderr, "invalid mark id: %n",p),2;
                  break;
	case '@': if(*p>='A' && *p<='Z') t=Mark[*p++-'A'];
                  else return fprintf(stderr, "invalid mark id: %n",p),2;
                  break;
	case '!': if(TLen+ClipLen>BUFF) tflush(BUFF-TLen,0);
                  if(TLen+ClipLen>BUFF) return fprintf(stderr, "out of bound: %n",p),3;
                  movp(ClipLen);
                  movmem(T+t,T+t+ClipLen,TLen-t);
		  movmem(Clip,T+t,ClipLen);
		  t+=ClipLen; TLen+=ClipLen;break;
	case '*': c=1; if(*p=='0') p++,c=0;
                  ll=get_number();
                  if(ll>0)               /* set limit */
                      Loop[LoopLevel+1].limit=ll;
                  else                  /* output */
                      {
                      if(*p=='\'')       /* format */
                          {
                          p++;
                          for(l=0;*p!='\''; p++,l++)
			     if(!*p) return fprintf(stderr,"missing '"),2;
                          movmem(p-l,format+1,l); format[l+1]=0; p++;
                          }
                      else  movmem("%u",format,3);

                      sprintf(tmpstr, format, Loop[LoopLevel].count+c);
/*                      printf("[%s/%s]",tmpstr,format); */
                      l=strlen(tmpstr);
                      if((long)TLen+l>=BUFF) tflush(l,0);
                      movmem(T+t,T+t+l,TLen-t); movmem(tmpstr,T+t,l);
                      t+=l; TLen+=l; movp(l);
                      }
                  break;
	case '{': /* if(t==TLen && End) skip('}'); */

                  Loop[++LoopLevel].count=0;
                  Loop[LoopLevel+1].limit=0; break;
	case '}': Loop[LoopLevel].count++;
                  if((t<TLen || !End) &&
                     (Loop[LoopLevel].limit==0 ||
                     Loop[LoopLevel].count < Loop[LoopLevel].limit))
			{
			c=0; --p;
			while(*--p!='{' || c)
			    {
			    if(p==Prog-1) return fprintf(stderr," missing {"),2;
			    if(*p=='}') c++; if(*p=='{') c--;
			    if(*p=='\'')
			      {while(*--p!='\'') if(p<=Prog)
				 fprintf(stderr,"missing '"),exit(2);}
			    }
			p++;
			}
                     else
                         LoopLevel--;
		  break;
	case '=': skip('}'); LoopLevel--; break;
	case '?': if(!test()) skip(':');  break;
        case '/': if(*p=='^') DelFrom=t,++p;
                  c=0; p1=p; /* save p */
                  FindCount=0;
                  while(t<=TLen || !End )
                      {
                      p=p1;                       /* restore p */
                      while(*p!=';' &&!c)          /* scan all conditions :; */
                        if(test()) c=1;
                        else   skip(':');          /* go to next condition */
                      if(c || t>=TLen) break;
                      ++t; FindCount++;            /* go to next char */
                      }
                  break;
	case ':': skip(';'); break;
        case ';': break;
	case '>': while( (t<TLen || tflush(0,1)) && T[t++]!='\n') ; break;
        case '<': while(t>0 && T[t-1]!='\n') t--; break;
        case '$': tflush(t,1); break;
	default: fprintf(stderr,"unrecognized code: %s",p); return 3;
	}
    while(!End) t=TLen,tflush(TLen,1);  /* write rest of file */
    write(fileno(stdout),T,TLen);
    return 0;
    }
void skip(char c)
    {
    char f=0;

    while(*p!=c || f)
	{
	if(*p==0 || f<0) fprintf(stderr,"missing '%c' @ %u",c,p-Prog),exit(2);
	if(*p=='{') f++; if(*p=='}') f--;
	if(*p=='\'')
	   {while(*++p!='\'') if(*p==0) fprintf(stderr,"missing '"),exit(2);}
	p++;
	}
    p++;
    }
void movp(int d)
    {
    int i;

    for(i=0; i<'Z'-'A';i++)
	{
	if(Mark[i]>t)
	   {
	   Mark[i]+=d;
	   if(Mark[i]<t) Mark[i]=t;
	   }
        }
    }
unsigned get_number(void)
    {
    unsigned i=0;

    while(*p>='0' && *p <='9') i=i*10+*p++-'0';
    return i;
    }
int wspace(void)
    {
    return T[t]==' ' || T[t]=='\t' || T[t]=='\n';
    }
int tflush(unsigned fp,int read_flag)
    {
    unsigned t1;
    long int r;

    if(DelFrom<BUFF)
        {
        movmem(T+t,T+DelFrom,TLen-t);
        TLen -= t-DelFrom;
        t=DelFrom;
        }
    if(!fp && t>BUFF/3) fp=t-BUFF/3;
    if(fp)
        {
        write(fileno(stdout),T,fp);
        movmem(T+fp,T,TLen-fp); TLen-=fp;
        t1=t; t=fp; movp(-fp);          /* move marks */
        t=t1-fp;                        /* restore pointer & correct it */
        if(DelFrom<BUFF) DelFrom=t;    /* correct DelFrom */
        }

    if(!read_flag || End) return 0;
    r=read((fileno(stdin)),T+TLen, BUFF/3*2-TLen);
    if(r>0) TLen+=r; else End=1;
    return r>0;
    }
int test(void)
    {
    int i,c1,c2,t1;
    char *p1,*p2;

     switch(*p++)
         {
         case '\'':

              c1=cmps();
              if(*p=='.' && p[1]=='.' && p[2]=='\'')
                  {
                  p +=3; c2=cmps();
                  return (c1>=0) && (c2<=0);
                  }
              else return !c1;

         case '[': c1=1; t1=t; c2=' '; p2=NULL;
             while(*p!=']')
                 {
                 if(!*p) fprintf(stderr,"missing ]"), exit(3);
                 if(t>TLen) c1=0;
                 if(!c1) p++;
                 else
                    {
                    if(t>=TLen && !End) tflush(0,1);
                    p1=p;
                    switch(*p)
                        {
                        case '+': break;
                        case '*': break;
                        case '_': c1=wspace(); break;
                        case '.': c1=!wspace(); break;
                        case '0': c1=(T[t]>='0' && T[t]<='9'); break;
                        case '~': c1=(T[t]=='\n'); break;
                        case '?': if(c2=='*') c2='?'; break;
                        case '\\': p++; /* no break! compare next char */
                        default: c1=(*p==T[t]);
                        }
                    t++; p++;
                    if(*p1=='*' || *p1=='+') c2=*p1,t-- ;
                    else
                        {
                        switch(c2)
                            {
                            case '*': if(!c1) c1=1,c2=' ',t--;
                                      else p=p1; //wait while c1
                                      break;
                            case '+': if(!c1) t--;
                                      else p=p1,c2='*';
                                      break;
                            }
                        }
                    if(p2 && !c1) c1=1, p=p2; // if p2 wait while c1
                    else p2=NULL;
                    if(c2=='?') c2=' ',t--, p=p2=p1+1;
                    }
                }
                t=t1; p++; return c1;


         case '!': if(t+ClipLen>TLen) tflush(0,1);
                   for(i=0;i<ClipLen;i++) if(T[t+i]!=Clip[i]) return 0;
                    return 1;
         case '_': return wspace();
         case '.': return !wspace();
         case '0': return T[t]>='0' && T[t]<='9';
         case '<': return t==0 || T[t-1]=='\n';
         case 'E': return t>=TLen && (End || !tflush(0,1));
         default: p--;
                 if(*p>='A' && *p<='Z') return t>=Mark[*p++ -'A'];
                 if(*p>='1' && *p<='9') return FindCount>=get_number();
                 fprintf(stderr,"unrecognized condition code: %s",p); exit(3);
         }
    return 0;
    }
int cmps(void) // compare text and pattern till '
    {
    int i=0,cs=0;

    while(*p!='\'')
        {
        if(!*p) fprintf(stderr,"missing \' in test"), exit(3);
        if(t+i>=TLen && !End) tflush(0,1);
        if(cs==0)
            {
            if(t+i>=TLen || T[t+i] < *p) cs=-1;
            else if(T[t+i] > *p) cs=1;
            }
        p++; i++;
        }
        p++;
    return cs;
    }
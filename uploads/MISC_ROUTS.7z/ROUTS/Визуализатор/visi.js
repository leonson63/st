// Streets, routs, cars visualisavion

// initial scope and coordinates
k=20; x=0; y=0;
w=800; h=600;


ie=new ActiveXObject("InternetExplorer.Application");
fso=new ActiveXObject("Scripting.FileSystemObject");

htm=WScript.ScriptFullName;
htm=htm.slice(0,-3)+".htm"
ie.Navigate(htm);
while(ie.Busy);
WScript.Sleep(200);
d=ie.document;
dc=d.frames("controls").document;
dm=d.frames("map_frame").document;

//WScript.Echo(d.frames("controls").document.all.length);

//b=d.body;
ie.Visible=true;

streets_file=htm.slice(0,-8)+"streets.rt";
str_h=fso.OpenTextFile(streets_file);
str_text=str_h.ReadAll();
sa=str_text.split(/\s+/);

i=0; str="";  str_a=""; n=true;
p1=""; p2="";

while(i<sa.length)
  {
  if(n)   // skip street name
    {
    i++, 
    p1=sa[i++]; p1+=" "+sa[i++];
    n=false;
    }
  while(sa[i].slice(0,1)=="/") i++;  // skip comment
  dir=sa[i++];
  if(dir!=";")			// not end of street
    {
    p2=sa[i++]+" "; p2+=sa[i++];
    switch(dir)
      {
      case "=": str+="m"+p1+"l"+p2; break;

      case ">": str_a+="m"+p1+"l"+p2; break;

      case "<": str_a+="m"+p2+"l"+p1; break;
      } 
    p1=p2;
    }
  else n=true;
  }
str+="e"; str_a+="e";
//WScript.Echo(str);
//WScript.Echo(str_a);
dm.all("streets").v=str;
dm.all("streets_a").v=str_a;

// ------------------ main loop ----------
cmd="";
while(cmd != "exit")
{
  WScript.Sleep(300);
  try 
    { 
    cmd=dc.all("cmd").value;
    if(cmd=="") cmd=dm.all("cmd").value;
    } 
  catch(e) {cmd="exit";}
  cmda=cmd.split(/\s+/);
  switch(cmda[0].toString())
    {
    case "move": move(cmda[1]); break;
    case "point": point(cmda[1],cmda[2]); break;
    }

  try {dc.all("cmd").value=""; dm.all("cmd").value="";} 
  catch(e) {}
}


// --------------- move throw map --------------------
function move(dir)
{
switch(dir)
  {
  case "far":  k=Math.round(k*1.3); break;
  case "near": k=Math.round(k/1.3); break;
  case "left": x=Math.round(x-w*k*0.3); break;
  case "right":x=Math.round(x+w*k*0.3); break;
  case "up":   y=Math.round(y-h*k*0.3); break;
  case "down": y=Math.round(y+h*k*0.3); break;
  }
dm.all("map").coordsize=(w*k).toString()+","+(h*k).toString();
dm.all("map").coordorigin=(x-w*k/2).toString()+","+(y-h*k/2).toString();
return;
}
// ---------------- click on map ---------------------
function point(ax,ay)
{
var b,mx,my,rx,ry,cr,fcr;

b=dm.body;
mx=parseInt(ax)-b.clientLeft-b.leftMargin+b.scrollLeft; 
my=parseInt(ay)-b.clientTop-b.topMargin+b.scrollTop;
rx=(mx-w/2)*k+x; ry=(my-h/2)*k+y;
fcr=lookCross(rx,ry).split(";");

//WScript.Echo(fcr[0]+" "+fcr[1]+" "+fcr[2]);

cr=dm.all("cross").style;
cr.width=cr.height=10*k;
cr.left=parseInt(fcr[1]); cr.top=parseInt(fcr[2]);

dc.all("info").innerHTML=
	"K="+k+
	"<br>MX="+mx+"<br>MY="+my+
	"<br><br>X="+rx+"<br>Y="+ry+
	"<br> �����: "+fcr[0] ;


return;
}
// =====================================================
function lookCross(lx,ly)
{
ln="";
n1=""; n2="";
dist2=Number.MAX_VALUE;
imin=0;

i=0; begin=true;
while(i<sa.length)
  {
  if(begin) {ln=sa[i++]; begin=false;}
  dx=parseInt(sa[i++]) - lx ;
  dy=parseInt(sa[i++]) - ly;
  d2=dx*dx+dy*dy;

  if(Math.abs(d2-dist2)<1) n2=ln; // second cross
//WScript.Echo(d2+" x="+sa[i-2]+" y="+sa[i-1]);
  if(d2<dist2)
    {
    dist2=d2;
    n1=ln; n2="";
    imin=i-2;
    }
  while(("><=;").indexOf(sa[i++])==-1 ) ; // skip til ><=;
  if(sa[i-1]==";") begin=true; // new street
  }
return n1+(n2==""? "":"/"+n2)+";"+sa[imin]+";"+sa[imin+1];
}
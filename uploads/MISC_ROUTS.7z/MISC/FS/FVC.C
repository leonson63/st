/* FVC - FS V-driver Command
provides command to MODEM via V-Driver

Usage:	FVC connect_string

Exits:
	0 - connection established;
	1 - connection NOT establishet;
	2 - no V-driver loaded;
	3 - no arguments;
        15 - command cancelled by user.

Note: NO terminating '|'!
*/
#include <DOS.h>
#include <conio.h>

#include "DL.h"

#define NO_RESPONSE	0xF
#define ID              'V'

extern void far Disp2fInit(void);
extern void far Disp2fKill(void);

struct REGPACK R;

int volatile Response=NO_RESPONSE;

int main(int argc,char **argv)
    {
    char *s,*p;

    if(argc==1) return 3;

    R.r_ax=DL_CHECK; R.r_bx=ID;

    intr(0x2f,&R);
    if(R.r_ax==DL_CHECK) return 2;

    Disp2fInit();

    s=argv[1]; R.r_bx=ID;
    p=s;
    while(*p) p++; *p++='|'; *p=0;
    R.r_ds=FP_SEG(s); R.r_si=FP_OFF(s);
    R.r_ax=DL_CONNECT;
    intr(0x2f,&R);
    while(Response==NO_RESPONSE)
	if(kbhit())
		{
		getch(),R.r_ax=DL_DISCONNECT,R.r_bx=ID;intr(0x2f,&R);
		break;
		}
    Disp2fKill();
    return Response;
    }

#pragma	argsused
void interrupt On_2f(bp, di, si, ds, es, dx, cx, bx, ax, ip, cs, flags)
    unsigned bp, di, si, ds, es, dx, cx, bx, ax, ip, cs, flags;
    {
    if(bx==ID)
      switch(ax)
	{
	case DLI_CONNECTED: Response=0; break;
	case DLI_DISCONNECTED: Response=1; break;
	}

    flags |=1;	/* chain on */
    }
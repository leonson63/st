
/* File Service
by A.Polyakov CSL, March'92 - August'94
*/

#include <DOS.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <string.h>
#include <dir.h>
#include <stdlib.h>

#include "Alex.h"
#include "DL.h"
#include "FS.h"

#if defined INDICATE
#include "IND.h"
#else
#define IND(a)
#endif

#define	VERSION		1
#define	flash(h)	close(dup(h))
#define	writes(h,b)	_write(h,&b,sizeof(b))
#define reads(h,b)	_read(h,&b,sizeof(b))
#define	s(n)		ltoa(n,D,10)

#define LOGSIZE		(10*1024)
#define LOGTILE		".old"

#define	UINT		geninterrupt(0x2f)
#define	MODEM		1
#define SIMNET		2

#define disconnect(d)	_BX=d,_AX=DL_DISCONNECT,UINT


#define	DATA_SIZE	1024		/* bytes */
#define S_DATA_SIZE	512		/* bytes */
#define	PAUSE		3		/* pause betwing connect attempts */
extern int errno;

typedef sf *fptr;
typedef int (fri)(void);
typedef fri *friptr;
/* ---------- DATA BLOCKS TYPES & CODING ------------ */
typedef enum {IDENT=0,PASSWORD,NOTHING,HEADER,ACKN,DATA,ERROR} types;
#define	R_FUNC	{r_ident,r_password,r_nothing,r_header,r_ackn,r_data,r_error}
/* ------------ Status structure -------------------- */
status S;

/* ------------- Send / Receive area structures --------- */
typedef struct
	{
	types	type;
	byte	data[DATA_SIZE];
	char	checksum;		/* reserved for CHECKSUM */
	} area;

area	Sa,Ra;		/* send & receive areas */
/* ------------------------------------------------------ */
extern	void far Disp2fInit(void);
extern	void far Disp2fKill(void);

sf treat;
char *c(char*,...);
char *newname(char*);
void log(char*,...);
int readstr(int,char*);
ui num(char*);

sf connected;
sf disconnected;
sf sent;
sf received;
sf next_file;
sf scan;
sf off;
sf message;
void rout(char *);
long secs(void);

fri r_ident, r_password, r_nothing, r_header, r_data, r_ackn, r_error;

int 	connect(char* node);
void	send(types);
void	_send(types);


intrpt On_28;

intrpt *Old_28;
intrpt On_timer;
intrpt *Old_timer;

int	M_SS,M_SP;
/* ------------------ EVENTS ----------------------------- */
#define	E_CONNECT	1
#define E_SENT		2
#define E_RECEIVED	4
#define	E_DISCONNECT	8
#define E_FILE		16
#define E_SCAN		32
#define	E_OFF		64
#define E_MESSAGE	128

#define	E_DONE		256		/* I have sent my DONE */
#define E_RDONE		512		/* I have treat remote DONE */
/* ------------------ Vars ------------------------------- */
unsigned Event=E_SCAN;			/* do scan */
byte	Off=NO;
long	Dnn_time=0;			/* Do next_node time */

int 	Disconnect_reason=0;
int	Bytes_received;
char far *Msg_ptr;
char	*Er_msg;			/* for send to remote */
byte	Version=0;			/* 0 - no checksum
					   1 - checksum enabled */

int     Sending=0;			/* bit mapped */

char	D[9];				/* template for ltoa() */

char	Node_name[13];			/* Own node name */
char	Wrk[65];			/* current working directory */
char	Tmp_name[65];			/* temp receiving path/file */
char	Protect=0;			/* if ='#' connect for # only */
char	S_password[32]="";      	/* password to send */
char	R_password[32]="";		/* password to check */

int	Log,Rd=0,Wr=0,Cn=0;		/* file handles */
/* ---------------------- functions itself ---------------- */
#pragma	argsused
void interrupt On_2f(bp, di, si, ds, es, dx, cx, bx, ax, ip, cs, flags)
    unsigned bp, di, si, ds, es, dx, cx, bx, ax, ip, cs, flags;
    {
    switch(ax)
	{
	case FS_CHECK:
		es=FP_SEG(&S); bx=FP_OFF(&S); ax|=0xFF;
		if(dx==OFF)
			{
			Off=YES; Event |=E_OFF;
			if(S.device) disconnect(S.device);
			break;
			}
		if(!dx) break;			/* no run */
		if(S.device==0 && Dnn_time==0) Event |=E_SCAN;  /* next node */
		break;
	case DLI_CONNECTED:
		if(!S.device || (S.device==bx && *S.node=='?'))
				/* if NOT connected or calling this*/
		    ax|=0xFF,S.device=bx,Dnn_time=0,Event|=E_CONNECT;
		else flags |=1;
		break;
	case DLI_SENT:
		if(bx==S.device) Event |=E_SENT;  /*Actualy_sent=cx;*/
		else flags |=1;
		break;
	case DLI_RECEIVED:
		if(bx==S.device) Event |=E_RECEIVED, Bytes_received=cx;
		else flags |=1;
		break;
	case DLI_DISCONNECTED:
		if(bx==S.device)
		    Disconnect_reason=dx,
		    Event = (Event&E_MESSAGE)|E_DISCONNECT;
		else flags |=1;
		break;
	case DLI_MESSAGE:
		Msg_ptr=MK_FP(ds,si), Event |=E_MESSAGE;
		ax=0xFFFF;
		break;
	default: flags |=1;
	}
    }
void interrupt On_28(void)
    {
    static into=NO;
    static fptr on_ev[]=
	{connected,sent,received,disconnected,
	 next_file,scan,off,message};
    ui	   old_psp;
    static O_SS,O_SP;
    int	   e,b;

    (*Old_28)();

    if(Dnn_time && secs()>Dnn_time)  Dnn_time=0,Event|=E_SCAN;

    if(Event && !into)
	{
	into=YES;
	_AH=0x62; geninterrupt(0x21); old_psp=_BX;
	_BX=_psp; _AH=0x50; geninterrupt(0x21);

	O_SS=_SS;O_SP=_SP; _SS=M_SS;_SP=M_SP;
        enable();

	for(e=0,b=1; e<NUM(on_ev); e++,b<<=1)
		if(Event&b) Event &= ~b,(*on_ev[e])();

	disable();
	_SS=O_SS;_SP=O_SP;
	_BX=old_psp; _AH=0x50; geninterrupt(0x21);
	into=NO;
	}
    }

sf received /* ----------- area received ---------------------- */
    {
    int i=0;
    char s=0;
    static friptr on_r[]=R_FUNC;
    IND('(');

    if(Sa.type==ERROR) return;
    if(Version>0)
	{
	while(i<Bytes_received) s+=((byte*)&Ra)[i++];   /* calc checksum */
	if(s) {log("\tchecksum error",NULL);disconnect(S.device);return;}
	Bytes_received--; 				/* remove it */
	}
    if((Ra.type<=ERROR || (log("protocol error",NULL),0)) &&
						(*on_r[Ra.type])() )
	{
	_BX=S.device;_DS=FP_SEG(&Ra);_SI=FP_OFF(&Ra);_CX=sizeof(Ra);
	_AX=DL_RECEIVE;UINT;
	}
    else disconnect(S.device);
    IND(')');
    }

sf connected
    {
    char d[2]={0,0};
    char day;

    IND('c');
    d[0]=S.device;
    _AH=0x2a; geninterrupt(0x21); day=_DL;
    log(s(day)," -------- connected via ",d,"-driver",NULL);
    _BX=S.device;_DS=FP_SEG(&Ra);_SI=FP_OFF(&Ra);_AX=DL_RECEIVE;UINT;
    Sending=0;
    send(IDENT);
    }
fri r_ident
    {
    int	h;

    IND('i');
    if(Bytes_received==0) return NO;	/* no ident - bad ident */

    if(Bytes_received> sizeof(Ra.type)+sizeof(Node_name))
	Version=Ra.data[sizeof(Node_name)];
    log("node: ",Ra.data," ver ",s(Version),NULL);
    *R_password=*S_password=0;
    if( (h=_open(c(Wrk,&Ra.data,"\\#\\PASSWORD.",NULL),O_RDONLY|O_BINARY))!=-1 )
	{
	readstr(h,S_password), readstr(h,R_password);
	if(*S.node=='?' && !strcmp(S.node+1,Ra.data))
	    readstr(h,S_password), readstr(h,R_password);
	close(h);
	}
    else if(Protect=='+')
	{
	log("unknown node: ",Ra.data,NULL);
	Er_msg="Unknown node"; send(ERROR); return OK;
	}
    else
	log("no password",NULL);
    strcpy(S.node,Ra.data);
    send(PASSWORD);
    return OK;
    }
fri r_password
    {
    IND('p');
    if(strcmp(Ra.data,R_password))
	{
	log("\twrong password: ",Ra.data,NULL);
	Er_msg="Access denied"; send(ERROR);
	}
    else
	log("\taccepted",NULL), S.sfd.ff_fsize=0, next_file();
    return OK;
    }
/* ---------------- find the oldest file ---------------- */
sf next_file
    {
    int	i=0;
    struct ffblk f;
    ul of=0xFFFFFFFFL;

    if(S.sfd.ff_fsize!=0) return;	/* already sending file */
    IND(',');
    while(i<sizeof(f.ff_name)) f.ff_name[i++]=0;   /* fill name with zeros */

    if(!findfirst( c(Wrk,S.node,"\\*.a??",NULL), &f, 0))
       {
       do if(*(ul*)&f.ff_ftime<of)
	   of=*(ul*)&f.ff_ftime,
	   memcpy(&S.sfd,&f.ff_attrib,sizeof(file_descr));
       while(!findnext(&f));
       }
    if(of==0xFFFFFFFFL) log("done",NULL), send(NOTHING);
    else log("send ",S.sfd.ff_name,", ",s(S.sfd.ff_fsize)," bytes",NULL),
	S.spos=0, send(HEADER);
    }
fri r_header
    {
    file_descr *fd=(file_descr*)&Ra.data;
    struct ffblk tmp;
    char *n;
    char attr;

    IND('h');
    if(Bytes_received<sizeof(file_descr)+1) return NO;
    log("\treceive ", fd->ff_name,", ",s(fd->ff_fsize)," bytes",NULL);
    n=c(Wrk,"TMP\\",fd->ff_name,NULL);
    attr=fd->ff_attrib;
    fd->ff_attrib=0;
    strcpy(strrchr(n,'.'),".*");	/* replace ext whith ".*" */
    if(!findfirst( n, &tmp, 0))
	{
	do
	    {
	    if(
		(Wr=_open( c(Wrk,"TMP\\",tmp.ff_name,NULL),
					    O_RDWR|O_BINARY))!=-1 &&
		lseek(Wr,-(long)sizeof(file_descr),SEEK_END)!=-1L &&
		reads(Wr,S.rfd)==sizeof(S.rfd) &&
		!memcmp(Ra.data,&S.rfd,sizeof(file_descr))
	       )
		 {lseek(Wr,-(long)sizeof(file_descr),SEEK_END); break;}
	    _close(Wr); Wr=0;
	    } while(!findnext(&tmp));
	}
    if(Wr>0)
	{
	strcpy(Tmp_name,c(Wrk,"TMP\\",tmp.ff_name,NULL));
	log("\tstart ",s(S.rpos=tell(Wr))," byte",NULL);
	}
    else
	{
	if(attr & FA_ARCH) /* -------- new file */
	    {
	    Wr=_creat(strcpy(Tmp_name,
	      newname(c(Wrk,"TMP\\",fd->ff_name,NULL))
			   ),FA_ARCH);
	    if(Wr<0)
		{
		Wr=0;
		log("\tTMP error ",s(errno),NULL);
		return NO;
		}
	    memcpy(&S.rfd,Ra.data,sizeof(file_descr));
	    writes(Wr,S.rfd);
	    lseek(Wr,0L,SEEK_SET); flash(Wr);
	    S.rpos=0;
	    }
	else		/* ---------- previous file */
	    {
	    S.rpos=fd->ff_fsize; /* ackn full file */
	    }
	}
    send(ACKN);
    return OK;
    }
fri r_ackn
    {
    char keep[64];
    char *nn;

    IND('a');
    if(*(long*)&Ra.data==S.sfd.ff_fsize)
	{
	if(Rd) close(Rd); Rd=0;
	if((Rd=_open( c(Wrk,S.node,"\\#\\keep",NULL),O_RDONLY))>0)
	   {
	   strcpy(keep,Wrk); readstr(Rd,keep+strlen(keep));
	   rename(c(Wrk,S.node,"\\",S.sfd.ff_name,NULL),
			(nn=newname( c(keep,"\\",S.sfd.ff_name,NULL))));
	   log("completed, keep as ",nn,NULL);
	   _close(Rd);
	   }
	else
	   {
	   unlink( c(Wrk,S.node,"\\",S.sfd.ff_name,NULL));
	   log("completed",NULL);
	   }
	Rd=0; S.sfd.ff_fsize=0; next_file();
	}
    else
	{
	_chmod(c(Wrk,S.node,"\\",S.sfd.ff_name,NULL),1,0); /* clear archive bit */
	if(!Rd && (Rd=_open(c (Wrk,S.node,"\\",S.sfd.ff_name,NULL),
			O_RDONLY|O_BINARY))==-1)
	    {
	    Rd=0,log("SEND open error ",s(errno),NULL);
	    return NO;
	    }

	if((S.spos=lseek (Rd,*(long*)&Ra.data,SEEK_SET))!=0L)
		log("starting ",s(S.spos), NULL);
	send(DATA);
	}
    return OK;
    }
fri r_data
    {
    IND('d');
    if(!Wr) return log("sys err 2"),NO;
    _write(Wr,&Ra.data,Bytes_received-1);
    if((S.rpos=tell(Wr))==S.rfd.ff_fsize)		/* full file */
	{
	chsize(Wr,S.rpos);	/* trancate length to correct */
	log("\tcompleted",NULL);
	treat();IND(':');
	S.rfd.ff_fsize=0;
	send(ACKN);
	}
    else
	{
	writes(Wr,S.rfd);
	lseek(Wr,-(long)sizeof(file_descr),SEEK_CUR); flash(Wr);
	}
    return OK;
    }
fri r_nothing
    {
    struct ffblk f;

    IND('n');
    log("\tdone",NULL);
    unlink( c(Wrk,S.node,"\\REQUEST",NULL) );		/* delete REQUEST file */
    if(findfirst( c(Wrk,S.node,"\\*.???",NULL), &f, 0) &&
	   (Event&E_DONE)) return NO;

    Event |=E_RDONE;
    next_file();
    return OK;
    }
fri r_error
    {
    log("Remote error: ",Ra.data,NULL);
    return NO;
    }
sf disconnected /* -------- disconnected ---------------------- */
    {
    IND('d');
    if(Wr)
	{
	log("\tcrash at ",s(S.rpos)," byte",NULL);
	writes(Wr,S.rfd),close(Wr),Wr=0;
	}
    if(Rd)
	{
	log("crash at ",s(S.spos), " byte",NULL);
	close(Rd),Rd=0;
	}
    S.rfd.ff_fsize=0; S.sfd.ff_fsize=0;
    Version=0;
    log("disconnected",NULL);
    flash(Log);
    S.device=0; *S.node=0;
    if(Off) off();
    else Dnn_time=secs()+PAUSE;
    }
sf scan
    {
    static char start=YES;
    static struct ffblk node;
	   struct ffblk file;
    static char	worked;
    static char routing=YES;

    IND(';');
    *S.node=0;					/* mark idle */

    while(1)
	{
	if(start) {findfirst( c(Wrk,"*.*",NULL), &node, FA_DIREC);
		if(routing && !worked) log("scanning...",NULL);
		worked=start=NO;}
	else

	if(node.ff_attrib==FA_DIREC &&          /* is it ordinary directory */
	   node.ff_name[0]!='.' &&        	/* isn't it . or .. */
	   !findfirst( c(Wrk,node.ff_name,"\\*.*",NULL),&file,0)
	  )                                     /* are there files */
	    {
	    if(routing)
		{
		if( (Cn=_open( c(Wrk,node.ff_name,"\\#\\ROUT.",NULL),
		    O_BINARY|O_RDONLY)) >0) worked=YES, rout(node.ff_name);
		}
	    else
		if(connect(node.ff_name)) {worked=YES; return;}
					/* do not change node! */
	    }

	 if(findnext(&node))	/* after last node */
	    {
	    start=YES;
	    if(!worked)      	/* it was idle loop */
		{
		if(routing) routing=NO;
		else {routing=YES; log("nothing.",NULL); flash(Log); return;}
				/* ... create CONNECT= "?N" for loop*/
		}
	    else routing=YES;
	    }
	}
    }
sf sent /* --------------- area sent -------------------------- */
    {
    int i;

    IND(']');
    if(Sa.type==ERROR) {disconnect(S.device);return;}
    if(Sa.type==NOTHING)
	{
	if(Event & E_RDONE && Ra.type==NOTHING) {disconnect(S.device);return;}
	Event |=E_DONE;
	}
    Sending &= ~(1<<Sa.type);		/* clear current sending bit */
    if(Rd && Sa.type==DATA && (S.spos=tell(Rd)) < S.sfd.ff_fsize)
	Sending |= 1<<DATA;
    if(Sending)			/* send next */
	for(i=0; i<15; i++) if(Sending&(1<<i)) {_send(i); break;}
    }
int connect(char* node)
    {
    int d,h;
    static char oldnode[13]="";
    static int  pos,line;
    static char cs[50];

    if(strcmp(node,oldnode)) strcpy(oldnode,node),pos=line=0;
    h=_open( c(Wrk,node,"\\#\\CONNECT.",NULL),O_BINARY|O_RDONLY);
    if(h==-1) return NO;
    if(lseek(h,(long)pos,SEEK_SET)==-1L) {*oldnode=0;_close(h); return NO;}
    readstr(h,cs); line++;
    if(*cs==0) {*oldnode=0; _close(h); return NO;} /* no more strings */
    else if(*cs=='?')
	{
	log("Delay ",cs+1," secs",NULL);
	Dnn_time=secs()+num(cs+1);
	}
    else
	{
	disable();
	if(S.device) return enable(),NO; /* INCOME CONNECT while thinking... */
	_BX=d=*cs,_DS=FP_SEG(cs),_SI=FP_OFF(cs)+1,_AX=DL_CONNECT,UINT;
	if(_AL!=0xFF)
	    {
	    enable(); cs[1]=0;
	    log("NO ready ",cs,"-driver found",NULL),flash(Log);
	    Dnn_time=secs()+1;  /* try next string after 1 sec */
	    }
	else
	    {
	    S.device=d; 	/* CONNECT_REQ accepted */
	    *S.node='?'; strcpy(S.node+1,node);
	    enable();
	    IND('C');log("Calling ",node," #",s(line),NULL);
	    }
	}
    pos=tell(h);
    _close(h);
    return 1; /* ok */
    }
void send(types ft)
    {
    int	r; 			/* actually read */

    IND('S');
    r=1<<ft;
    if((Sending|=r)==r) _send(ft);
    }
void _send(types ft)
    {
    int l,i=0;
    char s=0;

    switch(Sa.type=ft)
	{
	case IDENT: IND('I');strcpy(Sa.data,Node_name);
			    Sa.data[sizeof(Node_name)]=VERSION;
			    l=sizeof(Node_name) +1/* version */; break;
	case PASSWORD: IND('P');strcpy(Sa.data,S_password);
				l=strlen(Sa.data)+1/* term 0*/; break;
	case NOTHING: IND('N');l=0; break;
	case ACKN: IND('A'); *(long*)&Sa.data=S.rpos; l=sizeof(S.rpos); break;
	case HEADER: IND('H');
		memcpy(Sa.data,&S.sfd,sizeof(file_descr));
		l=sizeof(file_descr); break;
	case DATA:   IND('D');
		l=_read(Rd,Sa.data,S_DATA_SIZE);
		if(l==-1)
		   {log("src read error ",s(errno),NULL);
		   disconnect(S.device); return;}
		break;
	case ERROR: IND('E'); strcpy(Sa.data,Er_msg);l=strlen(Er_msg);
		break;
	}
    l++; /* add sizeof(Sa.type) */
    if(Version>0)
	{
	while(i<l) s+=((byte*)&Sa)[i++];/* calc checksum of area */
	((byte*)&Sa)[l++]=-s;           /* append it */
	}
    IND('[');
    _CX=l, _BX=S.device, _DS=FP_SEG(&Sa), _SI=FP_OFF(&Sa), _AX=DL_SEND, UINT;
    }
int readstr(int h,char *s)
    {
    int i=0;
    byte skip=NO;

    *s=0;
    while(!eof(h) && *s!='\n')
	{
	if(_read(h,s,1)==-1)
	    {log("readstr error ",s(errno),NULL); return 0;}
	if(*s=='{') skip=YES;
	if(*s>' ' && !skip) s++,i++;
	if(*s=='}') skip=NO;
	}
    *s=0;
    return i;
    }
sf off
    {
    int i=0;

    if(S.device) return;	/* I'm still connected !!! */
    log("Unloaded...",NULL);
    _close(Log);
    while(i<5) _close(i++);	/* close STDIN, STDOUT, STDERR etc */
    Disp2fKill();
    setvect(0x28,Old_28);
    S.psp=0;
    freemem(*(ui far*)MK_FP(_psp,0x2c)); 	/* release environment */
    freemem(_psp);                     		/* release itself */
    }
sf message
    {
    log(": ",Msg_ptr,NULL); *Msg_ptr=0;		/* mark logged */
    }
sf treat	/* Tmp_name */
    {
    unsigned char s[256];
    int	 n,l;
    struct ffblk f;
    char *p="OTHERS";
    char *nn;

    IND('=');
    if(filelength(Wr)>sizeof(s)) lseek(Wr,-(long)sizeof(s),SEEK_END);
    else lseek(Wr,0L,SEEK_SET);
    n=reads(Wr,s); 	   		/* read tile */
    if(n==-1) {log("treat read error ",s(errno),NULL);_close(Wr);Wr=0;return;}
    if(s[l=n-s[n-1]]=='R' && !findfirst( c(Wrk, &s[l+1],NULL),&f,FA_DIREC) )
	chsize(Wr,filelength(Wr)-(long)s[n-1]),
	p=s+l+1;
    else log("\t\tno rout",NULL);
    _close(Wr);Wr=0;
    if(rename(Tmp_name, nn=newname( c(Wrk, p,strrchr(Tmp_name,'\\'),NULL) )))
	unlink(Tmp_name),log("\trename error ",s(errno),", file deleted",NULL);
    else log("\tplace to ",p," as ",strrchr(nn,'\\')+1,NULL);
    if((Cn=_open(c(Wrk, p, "\\#\\ROUT.",NULL),O_RDONLY))!=-1) rout(p); /*rout further */
    else Cn=0;
    }
void rout(char *box)
    {
    char s[80]="-";
    char r[100]="";
    char *p=s;
    int	 i,n=0;
    struct ffblk fb;

    IND('R');
    readstr(Cn,s+1); _close(Cn); Cn=0;
    p=s+strlen(s);
    if(s[1]) while(p!=s)
	{
	for(i=0; p[-1]!='-'; p--) i++; 	/* find name and it's length */
	r[n++]='R'; strcpy(&r[n],p); n+=i+1 /*term 0 */; r[n++]=i+3;
	*(--p)=0; /* stant to '-' and delete it*/
	}
    else s[1]='.';
    log("\t\trouting from ",box,NULL);
    findfirst(c(Wrk,box,"\\*.*",NULL),&fb,0);
    do
	{
	log("\t\tfile ",fb.ff_name,NULL);
	Wr=_open(strcpy(Tmp_name,c(Wrk,box,"\\",fb.ff_name,NULL)),
		O_RDWR|O_BINARY|O_APPEND);
	if(Wr==-1) log("open error ",s(errno)," file ",Tmp_name,NULL);
	else write(Wr,r,n),treat();
	} while(!findnext(&fb));
    }
char *c(char*s, ...)		/* concatate many strings */
    {
    static char os[65];
    char **p=&s;

    *os=0;
    while(*p!=NULL) strcat(os,*p++);
    return os;
    }
char *newname(char* f)
    {
    static char s[65];
    char *p,*q;
    struct ffblk ff;
    long b[26];
    int  i=0,j;

    strcpy(s,f);
    p=strrchr(s,'.');
    if(p!=NULL) p++; else return s;
    while(i<26) b[i++]=0L; strcpy(p,"A??");
    while(1)
	{
	if(!findfirst(s,&ff,0xFF))
	    {
	    q=strrchr(ff.ff_name,'.')+1;
	    do  b[q[1]-'A']|=1L<<(q[2]-'A'); while(!findnext(&ff));
	    }
	for(i=0; i<26; i++) for(j=0; j<26; j++)
	   if(! (b[i] & (1L<<j))) {*++p='A'+i; *++p='A'+j; return s;}
       (*p)++;
       }
    }
void log(char*l, ...)		/* log many strings */
    {
    static char ls[79]="HH:MM:SS ";
    register char *t=ls;
    char **p=&l;
    int time[3];
    int	i;

    _AH=0x2C; geninterrupt(0x21); time[0]=_CH; time[1]=_CL; time[2]=_DH;
    for(i=0;i<3;i++) *t++=time[i]/10+'0', *t++=time[i]%10+'0',t++;
    ls[9]=0;
    while(*p!=NULL) strcat(ls,*p++);
    strcat(t,"\r\n");
    _write(Log,ls,strlen(ls));
    }
long secs(void)
    {
    asm {
	mov	ah,0x2c
	int	0x21
	mov	bx,60
	mov	al,ch
	mul	bl
	xor	ch,ch
	add	ax,cx
	mov	cl,dh
	mul	bx
	add	ax,cx
	adc	dx,0
	}
    return;
    }
ui num(char *p)
    {
    ui i=0;
    while(*p>='0') i=i*10-'0'+ *p++;
    return i;
    }
#pragma argsused
int main(int argc,char **argv)
    {
    char lss[10];
    ul log_size;
    char *p,*p1;
    int   h;
    int	  d,m,y;

    puts("File delivery Service V1.21 (C) A.Polyakov, August'94.");

    p=getenv("FS");
    if(p==NULL)  *strrchr(p=argv[0],'\\')=0;
    strcpy(Wrk,p);
    if(Wrk[strlen(Wrk)-1]!='\\') strcat(Wrk,"\\");

    if((h=_open(c(Wrk,"CONFIG.",NULL),O_RDONLY|O_BINARY))!=-1)
	{
	readstr(h,Node_name);
	readstr(h,R_password); Protect=*R_password;
	readstr(h,lss); log_size=1024L*num(lss);
	if(!log_size) log_size=LOGSIZE;
	close(h);
	}
    else {puts("No configuration file."); return 1;}
    p= argc>1? argv[1] : c(Wrk,"LOGOUT.",NULL);
    Log=_open(p,O_WRONLY|O_DENYWRITE);
    if(Log>0 && filelength(Log)>log_size)
	{
	_close(Log); Log=-1;
	strcpy(Tmp_name,p), p1=strrchr(Tmp_name,'.');
	if(p1) strcpy(p1,LOGTILE); else strcat(Tmp_name,LOGTILE);
	unlink(Tmp_name); /* delete possible previous old log */
	rename(p,Tmp_name);
	}
    if(Log==-1) Log=_creat(p,0);
    if(Log==-1) { puts("Can\'t open logout."); return 2;}
    lseek(Log,0L,SEEK_END);
    _AH=0x2a; geninterrupt(0x21); y=_CX; m=_DH; d=_DL;
    log(s(10000L*d+100L*m+y%100)," ============== Loaded",NULL);
    flash(Log);
    S.psp=_psp; S.device=0;

    M_SS=_SS; M_SP=_SP-256;
    Disp2fInit();
    Old_28=getvect(0x28); setvect(0x28,On_28);
    geninterrupt(0x28);	/* DO ROUTING TASK */

    puts("Installed.");

    keep(0, (_SS + (_SP/16) - _psp + 1));
    return 0;
    }
